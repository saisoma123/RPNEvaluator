fn main() {
    let x = 5;

    let mut y = false;

    if 0 < 5 {
        y = true;
    } else {
        y = false;
    }

    println!("Hello, world! y is: {}", y);
}
